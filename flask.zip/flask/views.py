from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.cluster.hierarchy as sch
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import datasets, linear_model
from sklearn.model_selection import train_test_split
from matplotlib import pyplot as plt
import matplotlib.pyplot as plt
#%matplotlib inline
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
  return render_template('index.html')
@app.route('/resultat',methods = ['GET'])
def resultat():
   
    result=request.form
    #data = pd.read_csv(result['nom'])
  #p = result['prenom']
    
    data = pd.read_csv('./Mall_Customers.csv');
    df = pd.DataFrame(data, columns=data.columns)
    data_train, data_test= train_test_split(df,test_size=0.2)
    X = data_train.iloc[:, [3,4]].values
    labels = range(1, 11)
    plt.figure(figsize=(10, 7))
    graph = plt.scatter(X[:,0],X[:,1], label='True Position')
    fig = graph.get_figure()
    filepath='./templates/image' 
    fig.savefig(filepath)
    return render_template("resultat.html",nom=fig)

app.run(debug=True)